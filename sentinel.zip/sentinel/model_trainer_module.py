from ultralytics import YOLO

# Load the specific YOLOv8 OBB pre-trained model
# This is the key difference: using 'yolov8n-obb.pt'
model = YOLO('yolov8n-obb.pt')

# Train the model using your dataset
results = model.train(
   data='sentinel/data.yaml',  # IMPORTANT: Update this path!
   epochs=75,          # Number of training cycles. 75 is a good start for a hackathon.
   imgsz=640,          # Image size for training.
   project='training_runs', # Directory to save results
   name='assembly_obb_v1' # Name for this specific training run
)

print("Training complete! Your trained model is saved in the 'training_runs/assembly_obb_v1' folder.")