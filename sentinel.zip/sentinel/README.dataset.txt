# Assembly-Inspector > edited_AI
https://universe.roboflow.com/hackathon-t9kca/assembly-inspector-mcyek

Provided by a Roboflow user
License: CC BY 4.0

